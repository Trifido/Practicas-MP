#ifndef _CODIFICAR_H_
#define _CODIFICAR_H_

void LeeLinea(char c[], int tamanio);
bool Ocultar(unsigned char imagen[],int n_pixel, const char mensaje[]);
bool Revelar(const unsigned char imagen[], int n_pixel, char mensaje[]);
    
#endif
