#ifndef _TRANSFORMAR_H_
#define _TRANSFORMAR_H_
#include "imagen.h"

bool Negativo(Imagen file);
bool Desplazar(int n, Imagen file);

#endif
